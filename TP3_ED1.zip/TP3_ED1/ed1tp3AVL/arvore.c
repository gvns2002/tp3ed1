#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"
#include <stdbool.h>

int preencheOperacao(){
    int op;
    while(1){
        scanf("%d", &op);
        if(op == 0 || op == 1 || op == 2)
            break;
        else{
            printf("Escolha inválida.\n");
            while(getchar() != '\n');
        }
    }
    return op;
}
 
RBTree* alocarArvore(){
    RBTree* temp = (RBTree*)malloc(sizeof(RBTree));
    if(temp == NULL)
        exit(1);
    arvoreInicia(temp);
    return temp;
}

void desalocarArvore(No** ppRaiz){
    if(*ppRaiz == NULL){
        desalocarArvore(&((*ppRaiz)->pEsq));
        desalocarArvore(&((*ppRaiz)->pDir));
        free((*ppRaiz));
    }
}

Pessoa* alocarPessoa(){
    Pessoa* temp = (Pessoa*)malloc(sizeof(Pessoa));
    if(temp == NULL)
        exit(1);
    return temp;
}

void arvoreInicia(No **ppRaiz){
    *ppRaiz = NULL;
}

bool insercao(No** ppRaiz, Pessoa x){
    if(*ppRaiz == NULL){
        *ppRaiz = criaNo(x);
        return true;
    }

    else if (x.idade < (*ppRaiz)->dado.idade) {
        if(insercao(&((*ppRaiz)->pEsq), x)) {
            if(Balanceamento(ppRaiz))
                return false;
            else
                return true;
        }
    } else if (x.idade > (*ppRaiz)->dado.idade) {
        if (insercao(&((*ppRaiz)->pDir), x)) {
            if (Balanceamento(ppRaiz))
                return false;
            else
                return true;
            }
    }

    return false;

}

No* criaNo(Pessoa x){
    No *pAux = (No*)malloc(sizeof(No));
    pAux->pEsq = NULL;
    pAux->pDir = NULL;
    pAux->dado = x;
    return pAux;
}

int FB(No *pRaiz) {
    return altura(pRaiz->pEsq) - altura(pRaiz->pDir);
}

int altura(No *pRaiz) {
    int iEsq, iDir;

    if(pRaiz == NULL)
        return 0;

    iEsq = altura(pRaiz->pEsq);
    iDir = altura(pRaiz->pDir);

    if(iEsq > iDir)
        return iEsq + 1;
    else 
        return iDir + 1;
}

void central(No* p){ //caminha em ordem crescente
    if(p == NULL)
        return; //vazia
    central(p->pEsq);
    imprimeNo(p);
    central(p->pDir);
}

void imprimeNo(No* p){
    printf("Nome: %s\n", p->dado.nome);
    printf("Idade: %d\n", p->dado.idade);
}

int Balanceamento(No **ppRaiz) {
    int fb = FB (*ppRaiz);
    if (fb > 1)
        return BalancaEsquerda(ppRaiz);
    else if (fb < -1)
        return BalancaDireita(ppRaiz);
    return 0;
}

int BalancaEsquerda(No **ppRaiz) {
    int fbe = FB ((*ppRaiz) -> pEsq);
    if (fbe >= 0)
        RSD (ppRaiz) ;
    else {
    /* Rotacao Dupla Direita */
        RSE (&((*ppRaiz) -> pEsq));
        RSD (ppRaiz) ; /* &(* ppRaiz ) */
    }
    return 1;
}

int BalancaDireita(No **ppRaiz) {
    int fbd = FB ((*ppRaiz) -> pDir);
    if (fbd <= 0)
        RSE (ppRaiz) ;
    else {
    /* Rotacao Dupla Direita */
        RSD (&((*ppRaiz) -> pDir));
        RSE (ppRaiz) ; /* &(* ppRaiz ) */
    }
    return 1;
}

void RSE(No **ppRaiz) {
    No* pAux;
    pAux = (*ppRaiz) -> pDir;
    (*ppRaiz) -> pDir = pAux -> pEsq;
    pAux -> pEsq = (*ppRaiz);
    (*ppRaiz) = pAux;
}

/* Manter como especificado */
void RSD(No **ppRaiz) {
    No* pAux;
    pAux = (*ppRaiz) -> pEsq;
    (*ppRaiz) -> pEsq = pAux -> pDir;
    pAux -> pDir = (*ppRaiz);
    (*ppRaiz) = pAux;
}