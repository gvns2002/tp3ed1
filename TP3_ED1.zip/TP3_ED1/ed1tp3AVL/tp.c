#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "arvore.h"

int main(int argc, char* argv[]){
    int operacao, n;
    RBTree* arvore;
    Pessoa* pessoa;

    arvore = alocarArvore();
    pessoa = alocarPessoa();

    do{
        operacao = preencheOperacao(); //verifica se a opcao escolhida é válida
        if(operacao == 0)
            break;

        else if(operacao == 1){
            scanf("%d", &n);
            for(int i = 0; i < n; i++){
                scanf("%s", pessoa->nome);
                scanf("%d", &(pessoa->idade));
                insercao(arvore, *pessoa);
            }
            

        } else if(operacao == 2){
            printf("Dados inOrder:\n");
            central(*arvore);
        }
    }while(1);

    printf("Dados inOrder:\n");
    central(*arvore);
    desalocarArvore(arvore);

    return 0;
}