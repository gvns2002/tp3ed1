#include <stdbool.h>

#ifndef arvore_h
#define arvore_h

// typedef struct{
//     int dia;
//     int mes;
//     int ano;
// }Nascimento;

typedef struct{
    char nome[21];
    //Nascimento data;
    int idade;
}Pessoa;

typedef struct no{
    Pessoa dado;
    char cor;  
    struct no* pai;  
    struct no* pEsq;
    struct no* pDir;
}No;

typedef No* RBTree;

void arvoreInicia(No **raiz);
int preencheOperacao();
void encaminhaOperacao(int op);
RBTree* alocarArvore();
Pessoa* alocarPessoa();
void desalocarArvore();
void leArvore(RBTree* arvore, Pessoa* pessoa);
bool insercao(No** cell, Pessoa x);
No* criaNo(Pessoa x);
void central(No* p);
void imprimeNo(No* p);

void RSD(No **ppRaiz);
void RSE(No **ppRaiz);
int BalancaDireita(No **ppRaiz);
int BalancaEsquerda(No **ppRaiz);
int Balanceamento(No **ppRaiz);
int altura(No *pRaiz);
int FB(No *pRaiz);



#endif