#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"
#include <stdbool.h>

int preencheOperacao(){
    int op;
    while(1){
        scanf("%d", &op); 
        if(op >= 0 && op <= 3)
            break;
        else{
            printf("Escolha inválida.\n");
            while(getchar() != '\n');
        }
    }
    return op;
}
 
RBTree* alocarArvore(){
    RBTree* temp = (RBTree*)malloc(sizeof(RBTree));
    if(temp == NULL)
        exit(1);
    arvoreInicia(temp);
    return temp;
}

void desalocarArvore(No* pRaiz){
    if(pRaiz != NULL){
        desalocarArvore(pRaiz->pEsq);
        desalocarArvore(pRaiz->pDir);
        free(pRaiz);
    }
}

Pessoa* alocarPessoa(){
    Pessoa* temp = (Pessoa*)malloc(sizeof(Pessoa));
    if(temp == NULL)
        exit(1);
    return temp;
}

void arvoreInicia(No **ppRaiz){
    *ppRaiz = NULL;
}

bool insercao(No** ppRaiz, Pessoa x){
    if(*ppRaiz == NULL){
        *ppRaiz = criaNo(x);
        (*ppRaiz)->cor = PRETO; // Novos nós são sempre pretos
        return true;
    }

    else if (x.idade < (*ppRaiz)->dado.idade) {
        if(insercao(&((*ppRaiz)->pEsq), x)) {
            (*ppRaiz)->pEsq->pai = *ppRaiz;
            if(balanceamento(ppRaiz))
                return false;
            else
                return true;
        }
    } else if (x.idade > (*ppRaiz)->dado.idade) {
        if (insercao(&((*ppRaiz)->pDir), x)) {
            (*ppRaiz)->pDir->pai = *ppRaiz;
            if (balanceamento(ppRaiz))
                return false;
            else
                return true;
            }
    }

    return false;
}

bool remocao(No** ppRaiz, int idade) {
    if (*ppRaiz == NULL) {
        // Element not found
        return false;
    }

    if (idade < (*ppRaiz)->dado.idade) {
        if (remocao(&((*ppRaiz)->pEsq), idade)) {
            // Perform fixup if necessary
            return balanceamento(ppRaiz);
        }
    } else if (idade > (*ppRaiz)->dado.idade) {
        if (remocao(&((*ppRaiz)->pDir), idade)) {
            // Perform fixup if necessary
            return balanceamento(ppRaiz);
        }
    } else {
        // Node with matching idade found, perform removal
        if ((*ppRaiz)->pEsq == NULL || (*ppRaiz)->pDir == NULL) {
            RBTree temp = (*ppRaiz)->pEsq ? (*ppRaiz)->pEsq : (*ppRaiz)->pDir;

            if (temp == NULL) {
                // No child or one child case
                temp = *ppRaiz;
                *ppRaiz = NULL;
            } else {
                // One child case
                *(*ppRaiz) = *temp;  // Copy the contents of the child
            }

            free(temp);
        } else {
            // Node with two children, find the successor (or predecessor) and replace
            RBTree successor = findMin((*ppRaiz)->pDir);
            (*ppRaiz)->dado = successor->dado;
            remocao(&((*ppRaiz)->pDir), successor->dado.idade);
        }

        // Perform fixup after removal
        return balanceamento(ppRaiz);
    }

    return false;
}

// Function to find the minimum element in a Red-Black tree
RBTree findMin(RBTree pRaiz) {
    while (pRaiz->pEsq != NULL) {
        pRaiz = pRaiz->pEsq;
    }
    return pRaiz;
}

No* criaNo(Pessoa x){
    No *pAux = (No*)malloc(sizeof(No));
    pAux->pEsq = NULL;
    pAux->pDir = NULL;
    pAux->dado = x;
    return pAux;
}

void central(No* p){ //caminha em ordem crescente
    if(p == NULL)
        return; //vazia
    central(p->pEsq);
    imprimeNo(p);
    central(p->pDir);
}

void imprimeNo(No* p){
    printf("Nome: %s\n", p->dado.nome);
    printf("Idade: %d\n", p->dado.idade);
}

int balanceamento(No **ppRaiz) {
    if (*ppRaiz != NULL) {
        (*ppRaiz)->cor = VERMELHO; // Novo nó sempre é colorido de vermelho depois da insercao
        if ((*ppRaiz)->pai != NULL && (*ppRaiz)->pai->cor == VERMELHO) {
            // Pai é vermelho, entao consertar
            RBTree avo = (*ppRaiz)->pai->pai; // Avo
            RBTree tio = (avo != NULL) ? (avo->pEsq == (*ppRaiz)->pai ? avo->pDir : avo->pEsq) : NULL;

            if (tio != NULL && tio->cor == VERMELHO) {
                // Caso 1: Tio eh vermelho
                (*ppRaiz)->pai->cor = PRETO;
                tio->cor = PRETO;
                avo->cor = VERMELHO;
                *ppRaiz = avo; // Caminhar pela arvore para buscar um potencial conserto
                return balanceamento(ppRaiz);
            } else {
                if ((*ppRaiz) == (*ppRaiz)->pai->pDir && (*ppRaiz)->pai == avo->pEsq) {
                    // Caso 2: Esquerdo-Direito
                    // Transformar em Caso 3
                    RSE(&((*ppRaiz)->pai));
                    *ppRaiz = (*ppRaiz)->pEsq; // Caminhar pela arvore para buscar um potencial conserto
                } else if ((*ppRaiz) == (*ppRaiz)->pai->pEsq && (*ppRaiz)->pai == avo->pDir) {
                    // Caso 2: Direito-Esquerdo
                    // Transformar em Caso 3
                    RSD(&((*ppRaiz)->pai));
                    *ppRaiz = (*ppRaiz)->pDir; // Caminhar pela arvore para buscar um potencial conserto
                }

                // Caso 3: Esquerdo-Esquerdo ou Direito-Direito
                (*ppRaiz)->pai->cor = PRETO;
                avo->cor = VERMELHO;
                if ((*ppRaiz) == (*ppRaiz)->pai->pEsq && (*ppRaiz)->pai == avo->pEsq) {
                    // caso Esquerdo-Esquerdo
                    RSD(&avo);
                } else {
                    // caso Direito-Direito
                    RSE(&avo);
                }
            }
        }
    }

    // Assegurar que a raiz seja preta
    (*ppRaiz)->cor = PRETO;
    return 0;
}

void RSE(No **ppRaiz) {
    No* pAux;
    pAux = (*ppRaiz) -> pDir;
    (*ppRaiz) -> pDir = pAux -> pEsq;
    pAux -> pEsq = (*ppRaiz);
    (*ppRaiz) = pAux;
}

/* Manter como especificado */
void RSD(No **ppRaiz) {
    No* pAux;
    pAux = (*ppRaiz) -> pEsq;
    (*ppRaiz) -> pEsq = pAux -> pDir;
    pAux -> pDir = (*ppRaiz);
    (*ppRaiz) = pAux;
}