#include <stdbool.h>

#ifndef arvore_h
#define arvore_h

typedef enum{
    VERMELHO, PRETO
}Cor;

typedef struct{
    char nome[21];
    int idade;
}Pessoa;

typedef struct no{
    Pessoa dado;
    Cor cor;
    struct no* pai;  
    struct no* pEsq;
    struct no* pDir;
}No;

typedef No* RBTree;

void arvoreInicia(No **raiz);
int preencheOperacao();
void encaminhaOperacao(int op);
RBTree* alocarArvore();
Pessoa* alocarPessoa();
void desalocarArvore(No* pRaiz);
void leArvore(RBTree* arvore, Pessoa* pessoa);
bool insercao(No** ppRaiz, Pessoa x);
bool remocao(No** ppRaiz, int idade);
RBTree findMin(RBTree pRaiz);
No* criaNo(Pessoa x);
void central(No* p);
void imprimeNo(No* p);

void RSD(No **ppRaiz);
void RSE(No **ppRaiz);
int balanceamento(No **ppRaiz);

#endif